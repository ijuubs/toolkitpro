import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { TOOLS } from '../data/toolsData';
import { Suspense, lazy, useEffect } from 'react';
import { trackToolView, trackToolUsage } from '../utils/analytics';
import { addRecentTool } from '../utils/recentTools';
import AdSlot from '../components/AdSlot';
import ErrorBoundary from '../components/ErrorBoundary';
import Breadcrumbs from '../components/Breadcrumbs';
import ReactMarkdown from 'react-markdown';
import { generateToolSEO, getToolCategoryInfo } from '../utils/seo';
import { getRelatedTools } from '../utils/relatedTools';
import { ToolSkeleton } from '../components/SkeletonLoader';
import { SITE_URL } from '../config/site';

// Lazy load tools
const WordCounter = lazy(() => import('../components/tools/WordCounter'));
const JsonFormatter = lazy(() => import('../components/tools/JsonFormatter'));
const PdfCompressor = lazy(() => import('../components/tools/PdfCompressor'));
const ImageResizer = lazy(() => import('../components/tools/ImageResizer'));
const QrCodeGenerator = lazy(() => import('../components/tools/QrCodeGenerator'));
const PasswordGenerator = lazy(() => import('../components/tools/PasswordGenerator'));
const BmiCalculator = lazy(() => import('../components/tools/BmiCalculator'));
const UrlEncoder = lazy(() => import('../components/tools/UrlEncoder'));
const Base64EncoderDecoder = lazy(() => import('../components/tools/Base64EncoderDecoder'));
const MarkdownToHtml = lazy(() => import('../components/tools/MarkdownToHtml'));
const LoremIpsum = lazy(() => import('../components/tools/LoremIpsum'));
const ColorPicker = lazy(() => import('../components/tools/ColorPicker'));
const UnitConverter = lazy(() => import('../components/tools/UnitConverter'));
const LoanCalculator = lazy(() => import('../components/tools/LoanCalculator'));
const PercentageCalculator = lazy(() => import('../components/tools/PercentageCalculator'));
const RoiCalculator = lazy(() => import('../components/tools/RoiCalculator'));
const SipCalculator = lazy(() => import('../components/tools/SipCalculator'));
const AgeCalculator = lazy(() => import('../components/tools/AgeCalculator'));
const TdeeCalculator = lazy(() => import('../components/tools/TdeeCalculator'));
const CompoundInterestCalculator = lazy(() => import('../components/tools/CompoundInterestCalculator'));

// Fiji Tools
const FijiSalaryCalculator = lazy(() => import('../components/tools/FijiSalaryCalculator'));
const FijiOvertimeCalculator = lazy(() => import('../components/tools/FijiOvertimeCalculator'));
const FijiAnnualLeaveCalculator = lazy(() => import('../components/tools/FijiAnnualLeaveCalculator'));
const FijiLoanRepaymentCalculator = lazy(() => import('../components/tools/FijiLoanRepaymentCalculator'));
const FijiMortgageCalculator = lazy(() => import('../components/tools/FijiMortgageCalculator'));
const FijiDutyImportCalculator = lazy(() => import('../components/tools/FijiDutyImportCalculator'));
const FijiVehicleCostCalculator = lazy(() => import('../components/tools/FijiVehicleCostCalculator'));
const FijiElectricityBillCalculator = lazy(() => import('../components/tools/FijiElectricityBillCalculator'));
const FijiGroceryBudgetCalculator = lazy(() => import('../components/tools/FijiGroceryBudgetCalculator'));
const FijiTaxiFareCalculator = lazy(() => import('../components/tools/FijiTaxiFareCalculator'));
const FijiVatCalculator = lazy(() => import('../components/tools/FijiVatCalculator'));
const FijiVatLodgementCalculator = lazy(() => import('../components/tools/FijiVatLodgementCalculator'));
const FijiFnpfCalculator = lazy(() => import('../components/tools/FijiFnpfCalculator'));
const FijiTslsCalculator = lazy(() => import('../components/tools/FijiTslsCalculator'));
const FijiBusinessStartupCostCalculator = lazy(() => import('../components/tools/FijiBusinessStartupCostCalculator'));
const FijiFinancialPlanner = lazy(() => import('../components/tools/FijiFinancialPlanner'));
const DiffChecker = lazy(() => import('../components/tools/DiffChecker'));

export default function ToolTemplate() {
  const { slug } = useParams<{ slug: string }>();
  
  // Find tool by primary slug first, then fallback to aliases
  const tool = TOOLS.find((t) => t.slug === slug) || TOOLS.find((t) => t.aliases && t.aliases.includes(slug || ''));

  useEffect(() => {
    if (tool) {
      trackToolView(tool.id, tool.name, tool.category);
      trackToolUsage(tool.id, tool.name, tool.category, 'open_tool');
      addRecentTool(tool.id);
    }
  }, [tool?.id]);

  if (!tool) {
    return (
      <div className="max-w-4xl mx-auto py-20 text-center space-y-6">
        <Helmet>
          <title>404 - Tool Not Found | ToolKitPro</title>
          <meta name="robots" content="noindex, follow" />
        </Helmet>
        <h1 className="text-6xl font-black uppercase">404</h1>
        <p className="text-2xl font-bold">Tool Not Found</p>
        <Link to="/" className="inline-block bg-yellow-400 border-4 border-black px-6 py-3 font-black uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-[2px] hover:translate-y-[2px] transition-all">
          Back to Dashboard
        </Link>
      </div>
    );
  }

  // Generate dynamic SEO metadata, canonical URL, and structured data
  const {
    displayTitle,
    titleTag,
    metaDescription,
    canonicalUrl,
    currentUrl,
    structuredData
  } = generateToolSEO(tool, slug);

  const renderTool = () => {
    switch(tool.id) {
        case 'word-counter': return <WordCounter />;
        case 'json-formatter': return <JsonFormatter />;
        case 'pdf-compressor': return <PdfCompressor />;
        case 'image-resizer': return <ImageResizer />;
        case 'qr-code-generator': return <QrCodeGenerator />;
        case 'password-generator': return <PasswordGenerator />;
        case 'bmi-calculator': return <BmiCalculator />;
        case 'url-encoder': return <UrlEncoder />;
        case 'base64-encoder-decoder': return <Base64EncoderDecoder />;
        case 'markdown-to-html': return <MarkdownToHtml />;
        case 'lorem-ipsum': return <LoremIpsum />;
        case 'color-picker': return <ColorPicker />;
        case 'unit-converter': return <UnitConverter />;
        case 'loan-calculator': return <LoanCalculator />;
        case 'percentage-calculator': return <PercentageCalculator />;
        case 'roi-calculator': return <RoiCalculator />;
        case 'sip-calculator': return <SipCalculator />;
        case 'age-calculator': return <AgeCalculator />;
        case 'tdee-calculator': return <TdeeCalculator />;
        case 'compound-interest-calculator': return <CompoundInterestCalculator />;
        
        // Fiji tools switch mapping
        case 'fiji-salary-calculator': return <FijiSalaryCalculator />;
        case 'fiji-overtime-calculator': return <FijiOvertimeCalculator />;
        case 'fiji-annual-leave-calculator': return <FijiAnnualLeaveCalculator />;
        case 'fiji-loan-repayment-calculator': return <FijiLoanRepaymentCalculator />;
        case 'fiji-mortgage-calculator': return <FijiMortgageCalculator />;
        case 'fiji-duty-import-calculator': return <FijiDutyImportCalculator />;
        case 'fiji-vehicle-cost-calculator': return <FijiVehicleCostCalculator />;
        case 'fiji-electricity-bill-calculator': return <FijiElectricityBillCalculator />;
        case 'fiji-grocery-budget-calculator': return <FijiGroceryBudgetCalculator />;
        case 'fiji-taxi-fare-calculator': return <FijiTaxiFareCalculator />;
        case 'fiji-vat-calculator': return <FijiVatCalculator />;
        case 'fiji-vat-lodgement-calculator': return <FijiVatLodgementCalculator />;
        case 'fiji-fnpf-calculator': return <FijiFnpfCalculator />;
        case 'fiji-tsls-calculator': return <FijiTslsCalculator />;
        case 'fiji-business-startup-cost': return <FijiBusinessStartupCostCalculator />;
        case 'fiji-financial-planner': return <FijiFinancialPlanner />;
        case 'diff-checker': return <DiffChecker />;
        
        default: return <p className="text-center text-[var(--muted)]">Tool interface for {tool.name} coming soon.</p>;
    }
  };

  return (
    <div className="flex flex-col lg:flex-row gap-8">
      {/* Sidebar */}
      <aside className="w-full lg:w-64 shrink-0 order-2 lg:order-1">
        <div className="space-y-6">
          <div className="bg-white border-4 border-black p-4 shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] sm:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="font-black uppercase text-lg mb-4 border-b-2 border-black pb-2">Tools</h3>
            <ul className="space-y-2">
              {TOOLS.map((t) => (
                <li key={t.id}>
                  <Link 
                    to={`/tools/${t.slug}`} 
                    className={`block p-2 text-sm font-bold border-2 border-transparent hover:border-black transition-all ${t.id === tool.id ? 'bg-yellow-200 border-black' : ''}`}
                  >
                    {t.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div className="hidden lg:block">
            <AdSlot adSlot="9791142997" adFormat="vertical" minHeight="600px" />
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 space-y-8 min-w-0 order-1 lg:order-2">
        <Helmet>
          <title>{titleTag}</title>
          <meta name="description" content={metaDescription} />
          
          <link rel="canonical" href={canonicalUrl} />
          <meta property="og:title" content={titleTag} />
          <meta property="og:description" content={metaDescription} />
          <meta property="og:url" content={canonicalUrl} />
          <meta property="og:type" content="website" />
          <meta property="og:image" content={
            (tool.category === 'Fiji Tools' || tool.id.startsWith('fiji-'))
              ? `${SITE_URL.replace(/\/+$/, '')}/images/blog/fiji_finance_hero.jpg`
              : (['Web Tools', 'Security'].includes(tool.category) || tool.id === 'diff-checker')
              ? `${SITE_URL.replace(/\/+$/, '')}/images/blog/developer_tools_hero.jpg`
              : tool.category === 'Text Tools'
              ? `${SITE_URL.replace(/\/+$/, '')}/images/blog/text_content_hero.jpg`
              : `${SITE_URL.replace(/\/+$/, '')}/images/blog/math_converters_hero.jpg`
          } />
          <meta property="og:image:width" content="1200" />
          <meta property="og:image:height" content="675" />
          
          <meta name="twitter:card" content="summary_large_image" />
          <meta name="twitter:title" content={titleTag} />
          <meta name="twitter:description" content={metaDescription} />
          <meta name="twitter:image" content={
            (tool.category === 'Fiji Tools' || tool.id.startsWith('fiji-'))
              ? `${SITE_URL.replace(/\/+$/, '')}/images/blog/fiji_finance_hero.jpg`
              : (['Web Tools', 'Security'].includes(tool.category) || tool.id === 'diff-checker')
              ? `${SITE_URL.replace(/\/+$/, '')}/images/blog/developer_tools_hero.jpg`
              : tool.category === 'Text Tools'
              ? `${SITE_URL.replace(/\/+$/, '')}/images/blog/text_content_hero.jpg`
              : `${SITE_URL.replace(/\/+$/, '')}/images/blog/math_converters_hero.jpg`
          } />

          <script type="application/ld+json">
            {JSON.stringify(structuredData)}
          </script>
        </Helmet>
        
        <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tighter uppercase mb-2 sm:mb-4 text-[var(--g6)] leading-tight break-words">
          {displayTitle}
        </h1>

        {(() => {
          const categoryInfo = getToolCategoryInfo(tool);
          const relatedTools = getRelatedTools(tool, 4);
          return (
            <>
              <Breadcrumbs skipSchema items={[
                { label: 'Home', path: '/' }, 
                { label: categoryInfo.name, path: `/${categoryInfo.slug}` }, 
                { label: tool.name }
              ]} />

              <div className="bg-[var(--surface)] border-4 border-black p-3.5 sm:p-6 md:p-8 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] sm:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] min-h-[400px] overflow-hidden">
                <ErrorBoundary>
                  <Suspense fallback={<ToolSkeleton />}>
                      {renderTool()}
                  </Suspense>
                </ErrorBoundary>
              </div>

              {['Fiji Tools', 'Finance Tools', 'Health', 'Health Tools'].includes(tool.category) && (
                <div className="p-3 bg-neutral-100 dark:bg-neutral-800 border-2 border-black text-xs font-bold flex items-center justify-between gap-2">
                  <span>Estimates provided for informational purposes only.</span>
                  <Link to="/disclaimer" className="underline uppercase font-black shrink-0 hover:text-yellow-600">
                    Read Disclaimer →
                  </Link>
                </div>
              )}

              {tool.usp && (
                  <div className="bg-black text-white p-3.5 sm:p-6 border-4 border-black shadow-[4px_4px_0px_0px_rgba(251,191,36,1)] sm:shadow-[8px_8px_0px_0px_rgba(251,191,36,1)] flex items-start gap-3 sm:gap-4">
                      <div className="bg-yellow-400 text-black px-2 py-1 rounded-sm font-black text-xs uppercase shrink-0">USP</div>
                      <p className="font-bold text-sm sm:text-base md:text-lg leading-tight uppercase italic">{tool.usp}</p>
                  </div>
              )}
              
              {/* Related Tools - Curated, Deterministic Internal Linking */}
              <section className="mt-8 sm:mt-10">
                <div className="flex items-center justify-between border-b-4 border-black pb-2 mb-4">
                  <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-[var(--g6)]">
                    Related Tools
                  </h2>
                  <Link 
                    to={`/${categoryInfo.slug}`}
                    className="text-xs sm:text-sm font-black uppercase tracking-wider underline hover:bg-yellow-300 px-2 py-0.5 transition-colors"
                  >
                    All {categoryInfo.name} →
                  </Link>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  {relatedTools.map(t => (
                    <Link 
                      key={t.id} 
                      to={`/tools/${t.slug}`} 
                      className="group p-4 border-3 border-black bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-[2px] hover:translate-y-[2px] hover:bg-yellow-50 transition-all flex flex-col justify-between"
                    >
                      <div>
                        <span className="inline-block bg-black text-white text-[10px] font-black uppercase px-1.5 py-0.5 mb-2">
                          {t.category}
                        </span>
                        <h3 className="font-black uppercase text-sm sm:text-base leading-snug group-hover:text-yellow-600 transition-colors">
                          {t.name}
                        </h3>
                        <p className="text-xs text-[var(--muted)] font-medium line-clamp-2 mt-1">
                          {t.description}
                        </p>
                      </div>
                      <div className="mt-3 pt-2 border-t border-black/20 flex items-center justify-between text-xs font-black uppercase text-black">
                        <span>Open Tool</span>
                        <span className="group-hover:translate-x-1 transition-transform">→</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>

              <section className="max-w-none mt-10 md:mt-12">
                <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-[var(--g6)] border-b-4 border-black pb-2 leading-tight">
                  How to use {displayTitle}
                </h2>
                <div className="text-[var(--muted)] leading-relaxed mt-4 sm:mt-6 text-sm sm:text-base markdown-body">
                  <ReactMarkdown
                    components={{
                      h1: ({ children }) => <h3 className="text-2xl font-black uppercase tracking-tight text-[var(--g6)] mt-8 mb-3 border-b-2 border-black pb-1">{children}</h3>,
                      h2: ({ children }) => <h3 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-[var(--g6)] mt-8 mb-3 border-b-2 border-black pb-1">{children}</h3>,
                      h3: ({ children }) => <h4 className="text-lg sm:text-xl font-black uppercase tracking-tight text-[var(--g6)] mt-6 mb-2">{children}</h4>,
                      h4: ({ children }) => <h5 className="text-base sm:text-lg font-bold uppercase tracking-tight text-[var(--g6)] mt-4 mb-2">{children}</h5>,
                      p: ({ children }) => <p className="mb-4 text-[var(--muted)] leading-relaxed font-medium text-sm sm:text-base">{children}</p>,
                      ul: ({ children }) => <ul className="list-disc list-outside ml-6 space-y-1.5 mb-4 text-[var(--muted)] font-medium">{children}</ul>,
                      ol: ({ children }) => <ol className="list-decimal list-outside ml-6 space-y-1.5 mb-4 text-[var(--muted)] font-medium">{children}</ol>,
                      li: ({ children }) => <li className="leading-relaxed pl-1">{children}</li>,
                      strong: ({ children }) => <strong className="font-black text-[var(--g6)]">{children}</strong>,
                      code: ({ children }) => <code className="px-1.5 py-0.5 bg-yellow-200 border border-black font-mono text-xs font-bold text-black">{children}</code>,
                      blockquote: ({ children }) => <blockquote className="border-l-4 border-black bg-yellow-100 p-3 my-4 italic font-bold">{children}</blockquote>,
                      a: ({ href, children }) => {
                        const isInternal = href && (href.startsWith('/') || href.includes('toolkitpro'));
                        if (isInternal) {
                          const targetPath = href.replace(/^https?:\/\/[^/]+/, '');
                          return (
                            <Link 
                              to={targetPath} 
                              className="font-black underline text-black hover:bg-yellow-300 px-1 py-0.5 border-b-2 border-black transition-colors inline-block"
                            >
                              {children}
                            </Link>
                          );
                        }
                        return (
                          <a 
                            href={href} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="font-black underline text-black hover:bg-yellow-300 px-1 py-0.5 transition-colors"
                          >
                            {children}
                          </a>
                        );
                      }
                    }}
                  >
                    {tool.howTo}
                  </ReactMarkdown>
                </div>
                
                <div className="my-6 sm:my-12 p-4 sm:p-8 md:p-10 bg-yellow-400 border-4 sm:border-8 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] sm:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)]">
                  <h3 className="text-lg sm:text-2xl font-black uppercase mb-2 sm:mb-4 leading-tight">Pro Tip</h3>
                  <p className="font-bold text-sm sm:text-base md:text-lg">Use keyboard shortcuts (Cmd/Ctrl + V) to instantly paste data into our tools for faster workflow.</p>
                </div>

                <AdSlot adSlot="9791142997" adFormat="auto" minHeight="250px" className="my-6 sm:my-12" />

                <h3 className="text-xl sm:text-3xl font-black uppercase tracking-tight text-[var(--g6)] mt-8 sm:mt-16 border-b-4 border-black pb-2 leading-tight">Frequently Asked Questions</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 mt-4 sm:mt-8">
                  {tool.faqs.map((faq, i) => (
                      <div key={i} className="p-4 sm:p-6 border-4 border-black bg-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] sm:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:shadow-none hover:translate-x-[2px] hover:translate-y-[2px] transition-all">
                          <h4 className="font-black uppercase mb-2 text-base sm:text-lg leading-tight">{faq.question}</h4>
                          <p className="text-[var(--muted)] font-medium text-xs sm:text-sm md:text-base">{faq.answer}</p>
                      </div>
                  ))}
                </div>
              </section>
            </>
          );
        })()}
      </div>
    </div>
  );
}
